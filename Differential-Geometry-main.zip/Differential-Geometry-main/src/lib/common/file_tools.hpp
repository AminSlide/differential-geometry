#ifndef FILE_TOOLS_H

#include <string>

namespace FileTools {
	bool is_file_exist(std::string fileName);

}



#endif

