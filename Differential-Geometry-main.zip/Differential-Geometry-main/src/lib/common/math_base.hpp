#ifndef MATH_BASE_H

#include <cmath>
#include <algorithm>

#ifndef M_PI
#define M_PI 3.14159265359
#endif


#endif